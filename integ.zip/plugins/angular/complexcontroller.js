var app = angular.module('sampleapp');

app.controller('ComplexController', [
  '$scope', '$element', 'title', 'productsFromDB', 'priceToPay', 'close',
  function($scope, $element, title, productsFromDB, priceToPay, close) {
  "use strict";
  $scope.computedFee = '';
  $scope.productsFromDB = productsFromDB;
  $scope.priceToPay = priceToPay;
  $scope.products = [];
  $scope.name = null;
  $scope.age = null;
  $scope.title = title;
      
  $scope.addelete = function (item) {
        $scope.temp = false
        for(var i=0;i<$scope.products.length;i++){
            if(item.productCode == $scope.products[i].productCode){
                $scope.temp = true;
            }
        }
        if($scope.temp) {
            var index = $scope.products.indexOf(item);
            $scope.products.splice(index, 1);
        } else{
            $scope.products.push(item);
        }
  },
  
  //  This close function doesn't need to use jQuery or bootstrap, because
  //  the button has the 'data-dismiss' attribute.
  $scope.close = function() {
      $element.modal('hide');
        $('body').removeClass('modal-open');
        $('.modal-backdrop').remove();
 	  close({        
        products: $scope.products,
        computedFee: $scope.computedFee
    }, 500); 
  };

  //  This cancel function must use the bootstrap, 'modal' function because
  //  the doesn't have the 'data-dismiss' attribute.
  $scope.cancel = function() {

    //  Manually hide the modal.
    $element.modal('hide');
        $('body').removeClass('modal-open');
        $('.modal-backdrop').remove();
    
    //  Now call close, returning control to the caller.
    close({
        products: $scope.products,
        computedFee: $scope.computedFee
    }, 500); // close, but give 500ms for bootstrap to animate
  };

}]);