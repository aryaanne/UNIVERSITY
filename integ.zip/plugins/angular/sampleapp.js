var app = angular.module('sampleapp', ['angularModalService', 'ngAnimate', 'ngRoute']); //jshint ignore:line
app.controller('MainController', ['$scope', 'ModalService', function ($scope, ModalService) {
    "use strict";

    $scope.product = null,
    $scope.isToggled = false,
    $scope.repairFee = 0;
    $scope.total = 0;
    $scope.totalStrap = 0;
    $scope.totalBatt = 0;
    $scope.totalAccs = 0;
    $scope.productsStrap = [],
    $scope.productsBattery = [],
    $scope.productsAccessory = [],
    $scope.complexResultStrap = [],
    $scope.complexResultBattery = [],
    $scope.complexResultAccessory = [],
    $scope.toggle = function () {
        $scope.isToggled = !$scope.isToggled;
    },
    $scope.getTotalStrap = function (){
        $scope.totalStrap = 0;
        for(var i = 0; i < $scope.complexResultStrap.length; i++){
            $scope.product = $scope.complexResultStrap[i];
            $scope.totalStrap += ($scope.product.priceEach * $scope.product.quantity);
        }
        return $scope.totalStrap;
    },
    $scope.getTotalBatt = function() {
        $scope.totalBatt = 0;
        for(var x = 0; x < $scope.complexResultBattery.length; x++){
            $scope.product = $scope.complexResultBattery[x];
            $scope.totalBatt += ($scope.product.priceEach * $scope.product.quantity);
        }
        return $scope.totalBatt;
    },
    $scope.getTotalAccs = function() {
        $scope.totalAccs = 0;
        for(var y = 0; y < $scope.complexResultAccessory.length; y++){
            $scope.product = $scope.complexResultAccessory[y];
            $scope.totalAccs += ($scope.product.priceEach * $scope.product.quantity);
        }
        return $scope.totalAccs;
    },    
    $scope.getTotal = function(){
        $scope.total = $scope.getTotalStrap() + $scope.getTotalBatt() + $scope.getTotalAccs();
    },
    $scope.showComplexStrap = function () {
        ModalService.showModal({
            templateUrl: "complexStrap.html", 
            controller : "ComplexController",
            inputs: {
                title: "Select Straps To Sell",
                productsFromDB: $scope.productsStrap,
                priceToPay: null
            }
        }).then(function (modal) {
            modal.element.modal();
            modal.close.then(function (result) {
                $scope.complexResultStrap = result.products;
            });
        });
    },
    $scope.showComplexBattery = function () {
        ModalService.showModal({
            templateUrl: "complexBattery.html", 
            controller : "ComplexController",
            inputs: {
                title: "Select Batteries To Sell",
                productsFromDB: $scope.productsBattery,
                priceToPay: null
            }
        }).then(function (modal) {
            modal.element.modal();
            modal.close.then(function (result) {
                $scope.complexResultBattery = result.products;
            });
        });
    };
    $scope.showComplexAccessory = function () {
        ModalService.showModal({
            templateUrl: "complexAccessory.html", 
            controller : "ComplexController",
            inputs: {
                title: "Select Accessories To Sell",
                productsFromDB: $scope.productsAccessory,
                priceToPay: null
            }
        }).then(function (modal) {
            modal.element.modal();
            modal.close.then(function (result) {
                $scope.complexResultAccessory = result.products;
            });
        });
    },
    $scope.showComplexPayment = function () {
        $scope.priceToPay = $scope.repairFee + $scope.total;
        ModalService.showModal({
            templateUrl: "complexPayment.html", 
            controller : "ComplexController",
            inputs: {
                title: "Total Price Computation",
                productsFromDB: null,
                priceToPay: $scope.priceToPay
            }
        }).then(function (modal) {
            modal.element.modal();
            modal.close.then(function (result) {
                $scope.complexResultPrice = result.computedFee;
            });
        });
    }
}]);